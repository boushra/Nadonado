var bio = {
    name: 'boushra',
    role: 'developer',
    contacts: {
        mobile: '05555555',
        email: 'gggg@gmal.com',
        github: 'boushra dev ',
        twitter: '@boushra ',
        location: 'saudi arabia ',
    },
    welcomeMessage: ' welcom to my profile this s profile to show you about me ',
    skills: [' html ', 'css', 'java script ', ' php '],
    biopic: 'images/fry.jpg',
    display: function() {

        var forattedName = HTMLheaderName.replace('%data%', bio.name);
        var formattedRole = HTMLheaderRole.replace('%data%', bio.role);
        var formattedMobile = HTMLmobile.replace('%data%', bio.contacts.mobile);
        var formattedEmail = HTMLemail.replace('%data%', bio.contacts.email);
        var formattedGithub = HTMLgithub.replace('%data%', bio.contacts.github);
        var formattedLocation = HTMLlocation.replace('%data%', bio.contacts.location);
        var forattedWelcomeMessage = HTMLwelcomeMsg.replace('%data%', bio.welcomeMessage);
        var forattedBioPic = HTMLbioPic.replace('%data%', bio.biopic);

        $('#header').prepend(forattedName + formattedRole);
        $('#topContacts').append(formattedMobile + formattedEmail + formattedGithub + formattedLocation);
        $('#footerContacts').append(formattedMobile + formattedEmail + formattedGithub + formattedLocation);
        $('#header').append(forattedWelcomeMessage);
        $('#header').append(forattedBioPic);


        if(bio.skills.length > 0) {

            $('#header').append(HTMLskillsStart);
            bio.skills.forEach(function(skill) {
                var formattedSkills = HTMLskills.replace('%data%', skill);
                $('#skills').append(formattedSkills);
            });

        }
    },
};

bio.display();

var work = {

    jobs: [{
            'employer': 'boushra ali',
            'title': 'front end ',
            'location': 'taif',
            'dates': 'dec 2016',
            'description': ' work in taif nv and work in minstry of educaion ',
        },
        {
            'employer': 'boushra ali',
            'title': 'front end ',
            'location': 'taif',
            'dates': 'dec 2016',
            'description': ' work in taif nv and work in minstry of educaion ',
        },

        {
            'employer': 'boushra ali',
            'title': 'front end ',
            'location': 'taif',
            'dates': 'dec 2016',
            'description': ' work in taif nv and work in minstry of educaion ',
        },
        {
            'employer': 'boushra ali',
            'title': 'front end ',
            'location': 'taif',
            'dates': 'dec 2016',
            'description': ' work in taif nv and work in minstry of educaion ',
        },
        {
            'employer': 'boushra ali',
            'title': 'front end ',
            'location': 'taif',
            'dates': 'dec 2016',
            'description': ' work in taif nv and work in minstry of educaion ',
        }




    ],
    display: function() {

        $('#workExperience').append(HTMLworkStart);

        work.jobs.forEach(function(job)


            {
                var formatedHTMLworkEmployer = HTMLworkEmployer.replace('%data%', job.employer);
                var formatedHTMLworkTitlel = HTMLworkTitle.replace('%data%', job.title);
                var formatedHTMLworkLocation = HTMLworkLocation.replace('%data%', job.location);
                var formatedHTMLworkDates = HTMLworkDates.replace('%data%', job.dates);
                var formatedHTMLworkDescription = HTMLworkDescription.replace('%data%', job.description);

                $('.work-entry:last').append(formatedHTMLworkEmployer);

                $('.work-entry:last').append(formatedHTMLworkTitlel);

                $('.work-entry:last').append(formatedHTMLworkLocation);
                $('.work-entry:last').append(formatedHTMLworkDates);
                $('.work-entry:last').append(formatedHTMLworkDescription);




            });



    },
};


work.display();


var projects = {

    'projects': [{
            'title': 'forest',
            'dates': '2017- april',
            'description': 'display informaton about forest in the world ',
            'images': ['images/frist.png'],
        },
        {
            'title': 'forest',
            'dates': '2017- april',
            'description': 'display informaton about forest in the world ',
            'images': ['images/frist.png'],
        },
        {
            'title': 'teach in india ',
            'dates': '2017- dec',
            'description': 'display informaton about teach in india ',
            'images': ['images/second.jpg'],
        }
    ],
    display: function() {

        if(projects.projects.length > 0) {
            projects.projects.forEach(function(p) {
                $('#projects').append(HTMLprojectStart);

                var formatedprojectTitle = HTMLprojectTitle.replace('%data%', p.title);
                var formatedprojectDates = HTMLprojectDates.replace('%data%', p.dates);
                var formatedprojectDescription = HTMLprojectDescription.replace('%data%', p.description);


                $('.project-entry:last').append(formatedprojectTitle);

                $('.project-entry:last').append(formatedprojectDates);

                $('.project-entry:last').append(formatedprojectDescription);

                p.images.forEach(function(img)

                    {
                        var formatedprojectImage = HTMLprojectImage.replace('%data%', img);
                        $('.project-entry:last').append(formatedprojectImage);

                    });

            });

        }
    },
};


projects.display();


var education = {

    schools: [{
        'name': 'taif unversity ',
        'location': 'taif',
        'degree': 'Bsc',
        'majors': ['comupter since'],
        'dates': '2013-2011',
    }],
    onlineCourses: [{
        'title': 'front end dev ',
        'school': 'udacity',
        'dates': '2016',
        'url': 'udacity.com',
    }],
    display: function() {

        education.schools.forEach(function(school)

            {
                var formatedschoolName = HTMLschoolName.replace('%data%', school.name);
                var formatedschoolDegree = HTMLschoolDegree.replace('%data%', school.degree);
                var formatedschoolDates = HTMLschoolDates.replace('%data%', school.dates);
                var formatedschoolLocation = HTMLschoolLocation.replace('%data%', school.location);
                var formatedschoolMajor = HTMLschoolMajor.replace('%data%', school.majors);
                $('#education').append(HTMLschoolStart);
                $('.education-entry:last').append(formatedschoolName);
                $('.education-entry:last').append(formatedschoolDegree);
                $('.education-entry:last').append(formatedschoolDates);
                $('.education-entry:last').append(formatedschoolLocation);
                $('.education-entry:last').append(formatedschoolMajor);


            });


        $('#education').append(HTMLonlineClasses);
        education.onlineCourses.forEach(function(online) {
            var formatedonlineTitlee = HTMLonlineTitle.replace('%data%', online.title);
            var formatedonlineSchool = HTMLonlineSchool.replace('%data%', online.school);
            var formatedonlineDates = HTMLonlineDates.replace('%data%', online.dates);
            var formatedonlineURL = HTMLonlineURL.replace('%data%', online.url);

            $('.education-entry:last').append(formatedonlineTitlee);
            $('.education-entry:last').append(formatedonlineSchool);
            $('.education-entry:last').append(formatedonlineDates);
            $('.education-entry:last').append(formatedonlineURL);

        });




    },



};

education.display();

$('#mapDiv').append(googleMap);